﻿using Microsoft.AspNetCore.SignalR;

namespace Ass3_MVC_SignalR.Hubs
{
    public class SignalrServer : Hub
    {
    }
}
