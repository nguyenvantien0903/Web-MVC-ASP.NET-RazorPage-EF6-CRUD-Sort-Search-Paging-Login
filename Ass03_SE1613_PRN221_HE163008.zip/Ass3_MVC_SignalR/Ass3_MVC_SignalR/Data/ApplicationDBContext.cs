﻿using Ass3_MVC_SignalR.Models;
using Microsoft.EntityFrameworkCore;

namespace Ass3_MVC_SignalR.Data
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
            : base(options)
        {
        }

        public DbSet<AppUser> AppUsers { get; set; } = default!;

        public DbSet<Post> Posts { get; set; } = default!;

        public DbSet<PostCategory> PostCategories { get; set; } = default!;
    }
}
