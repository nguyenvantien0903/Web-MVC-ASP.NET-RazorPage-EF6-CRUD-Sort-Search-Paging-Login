﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ass3_MVC_SignalR.Data;
using Ass3_MVC_SignalR.Models;
using Microsoft.AspNetCore.SignalR;
using Ass3_MVC_SignalR.Hubs;
using Ass3_MVC_SignalR.Models.Paging;

namespace Ass3_MVC_SignalR.Controllers
{
    public class PostsController : Controller
    {
        private readonly ApplicationDBContext _context;
        private readonly IHubContext<SignalrServer> _signalRHub;
        private readonly IConfiguration Configuration;

        public PostsController(ApplicationDBContext context,IHubContext<SignalrServer> signalRHub, IConfiguration configuration)
        {
            _context = context;
            _signalRHub = signalRHub;
            Configuration = configuration;
        }

        // GET: Posts
        public async Task<IActionResult> Index(string search, string sortOrder,int pg=1,int pageSize=5)
        {
            if (HttpContext.Session.GetString("account") != null)
            {
                if (String.IsNullOrEmpty(search))
                {
                    search = String.Empty;
                }
                var applicationDBContext = _context.Posts.Include(p => p.Author).Include(p => p.Category).Where(p => p.Title.Contains(search)
                || p.Category.Description.Contains(search) || p.PostID.ToString().Equals(search));

                ViewBag.TitleSortParm = String.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
                ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";
                ViewBag.SearchData = search;    
                switch (sortOrder)
                {
                    case "title_desc":
                        applicationDBContext = applicationDBContext.OrderByDescending(s => s.Title);
                        break;
                    case "Date":
                        applicationDBContext = applicationDBContext.OrderBy(s => s.CreatedDate);
                        break;
                    case "date_desc":
                        applicationDBContext = applicationDBContext.OrderByDescending(s => s.CreatedDate);
                        break;
                    default:
                        applicationDBContext = applicationDBContext.OrderBy(s => s.Title);
                        break;
                }
                var units = applicationDBContext.ToList();
                var pager = new PaginatedList(units.Count, pg,search,sortOrder, pageSize);
                ViewBag.Pager = pager;

                units = units.Skip((pg - 1) * pageSize).Take(pageSize).ToList();

                return View(units);
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }

        // GET: Posts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Posts == null)
            {
                return NotFound();
            }

            var post = await _context.Posts
                .Include(p => p.Author)
                .Include(p => p.Category)
                .FirstOrDefaultAsync(m => m.PostID == id);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        // GET: Posts/Create
        public IActionResult Create()
        {
            ViewData["AuthorID"] = new SelectList(_context.AppUsers, "UserID", "Fullname");
            ViewData["CategoryID"] = new SelectList(_context.PostCategories, "CategoryID", "CategoryName");
            return View();
        }

        // POST: Posts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PostID,CreatedDate,UpdatedDate,Title,Content,PublishStatus,CategoryID,AuthorID")] Post post)
        {
            if (ModelState.IsValid)
            {
                _context.Add(post);
                await _context.SaveChangesAsync();
                await _signalRHub.Clients.All.SendAsync("LoadPosts");
                return RedirectToAction(nameof(Index));
            }
            ViewData["AuthorID"] = new SelectList(_context.AppUsers, "UserID", "UserID", post.AuthorID);
            ViewData["CategoryID"] = new SelectList(_context.PostCategories, "CategoryID", "CategoryID", post.CategoryID);
            return View(post);
        }

        // GET: Posts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Posts == null)
            {
                return NotFound();
            }

            var post = await _context.Posts.FindAsync(id);
            if (post == null)
            {
                return NotFound();
            }
            ViewData["AuthorID"] = new SelectList(_context.AppUsers, "UserID", "Fullname", post.AuthorID);
            ViewData["CategoryID"] = new SelectList(_context.PostCategories, "CategoryID", "CategoryName", post.CategoryID);
            return View(post);
        }

        // POST: Posts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PostID,CreatedDate,UpdatedDate,Title,Content,PublishStatus,CategoryID,AuthorID")] Post post)
        {
            if (id != post.PostID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(post);
                    await _context.SaveChangesAsync();
                    await _signalRHub.Clients.All.SendAsync("LoadPosts");
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PostExists(post.PostID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AuthorID"] = new SelectList(_context.AppUsers, "UserID", "UserID", post.AuthorID);
            ViewData["CategoryID"] = new SelectList(_context.PostCategories, "CategoryID", "CategoryID", post.CategoryID);
            return View(post);
        }

        // GET: Posts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Posts == null)
            {
                return NotFound();
            }

            var post = await _context.Posts
                .Include(p => p.Author)
                .Include(p => p.Category)
                .FirstOrDefaultAsync(m => m.PostID == id);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        // POST: Posts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Posts == null)
            {
                return Problem("Entity set 'ApplicationDBContext.Posts'  is null.");
            }
            var post = await _context.Posts.FindAsync(id);
            if (post != null)
            {
                _context.Posts.Remove(post);
            }
            
            await _context.SaveChangesAsync();
            await _signalRHub.Clients.All.SendAsync("LoadPosts");
            return RedirectToAction(nameof(Index));
        }

        private bool PostExists(int id)
        {
          return _context.Posts.Any(e => e.PostID == id);
        }
    }
}
