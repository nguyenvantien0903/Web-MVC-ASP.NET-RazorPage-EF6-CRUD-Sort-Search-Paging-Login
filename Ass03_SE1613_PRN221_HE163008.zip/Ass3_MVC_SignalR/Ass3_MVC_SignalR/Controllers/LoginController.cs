﻿using Ass3_MVC_SignalR.Data;
using Ass3_MVC_SignalR.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Ass3_MVC_SignalR.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDBContext _context;

        public LoginController(ApplicationDBContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(AppUser appUser)
        {
            var checklogin = _context.AppUsers.Where(x => x.Email.Equals(appUser.Email) && x.Password.Equals(appUser.Password)).FirstOrDefault();
            if(checklogin != null)
            {
                AppUser user = _context.AppUsers.FirstOrDefault(x => x.Email.Equals(appUser.Email) && x.Password.Equals(appUser.Password));
                HttpContext.Session.SetString("account", JsonConvert.SerializeObject(user));
                return RedirectToAction("Index","Posts");
            }
            else
            {
                ViewBag.Notification = "Wrong Email or Password";
                return View();
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index","Login");
        }
    }
}
