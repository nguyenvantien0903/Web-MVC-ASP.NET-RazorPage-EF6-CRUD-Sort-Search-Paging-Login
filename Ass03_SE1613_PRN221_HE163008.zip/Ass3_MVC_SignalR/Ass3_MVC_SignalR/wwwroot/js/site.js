﻿"use strict";

var connection = new signalR.HubConnectionBuilder()
    .withUrl("/signalrServer")
    .build();

connection.on("LoadPosts", function () {
    location.href='/Posts'
});

connection.on("LoadUsers", function () {
    location.href = '/AppUsers'
});
connection.start().catch(function (err) {
    return console.error(err.toString());
});